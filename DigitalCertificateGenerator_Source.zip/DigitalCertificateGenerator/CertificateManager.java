import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Core class of the application. Stores participants, prevents duplicates,
 * assigns certificate IDs and generates certificates (single or batch).
 */
public class CertificateManager {

    public static final String REPORT_NAME = "generation_report.txt";

    private final List<Participant> participants = new ArrayList<>();      // keeps order
    private final Map<String, Participant> emailIndex = new HashMap<>();   // O(1) lookup by e-mail
    private Event event;
    private int nextSequence = 1;

    /** Result of a CSV import: how many rows were added / skipped and why. */
    public static class ImportSummary {
        private int added;
        private int skipped;
        private final List<String> errors = new ArrayList<>();

        public int getAdded()          { return added; }
        public int getSkipped()        { return skipped; }
        public List<String> getErrors() { return errors; }
    }

    // ---------------------------------------------------------------- event
    public void setEvent(Event event) { this.event = event; }
    public Event getEvent()           { return event; }

    // --------------------------------------------------------- participants
    public int getParticipantCount() { return participants.size(); }

    public List<Participant> getParticipants() {
        return Collections.unmodifiableList(participants);
    }

    /** Validates, normalises and stores one participant. */
    public Participant addParticipant(String rawName, String rawEmail, String rawDept)
            throws InvalidInputException {
        String name = Validator.cleanName(rawName);
        String email = Validator.cleanEmail(rawEmail);
        String dept = Validator.cleanText("Department", rawDept, 2, 40);

        if (emailIndex.containsKey(email)) {                     // duplicate detection
            throw new InvalidInputException("Duplicate entry: " + email + " is already registered.");
        }
        String id = String.format("CERT-%04d", nextSequence++);   // unique, sequential ID
        Participant p = new Participant(name, email, dept, id);
        participants.add(p);
        emailIndex.put(email, p);
        return p;
    }

    public Participant findByEmail(String rawEmail) throws InvalidInputException {
        String email = Validator.cleanEmail(rawEmail);
        Participant p = emailIndex.get(email);
        if (p == null) {
            throw new InvalidInputException("No participant found with e-mail " + email + ".");
        }
        return p;
    }

    public void removeParticipant(String rawEmail) throws InvalidInputException {
        Participant p = findByEmail(rawEmail);
        participants.remove(p);
        emailIndex.remove(p.getEmail());
    }

    /** Case-insensitive search on name, e-mail, department or certificate ID. */
    public List<Participant> search(String keyword) {
        List<Participant> found = new ArrayList<>();
        String key = keyword.trim().toLowerCase();
        if (key.isEmpty()) {
            return found;
        }
        for (Participant p : participants) {
            if (p.getName().toLowerCase().contains(key)
                    || p.getEmail().contains(key)
                    || p.getDepartment().toLowerCase().contains(key)
                    || p.getCertificateId().toLowerCase().contains(key)) {
                found.add(p);
            }
        }
        return found;
    }

    /** Reads "name,email,department" rows; bad rows are skipped and reported. */
    public ImportSummary importFromCsv(File csv) throws IOException {
        ImportSummary summary = new ImportSummary();
        try (BufferedReader br = new BufferedReader(new FileReader(csv, StandardCharsets.UTF_8))) {
            String line;
            int lineNo = 0;
            while ((line = br.readLine()) != null) {
                lineNo++;
                if (line.trim().isEmpty()) {
                    continue;
                }
                String[] f = line.split(",", -1);
                if (lineNo == 1 && f[0].trim().equalsIgnoreCase("name")) {
                    continue;                                      // header row
                }
                try {
                    if (f.length != 3) {
                        throw new InvalidInputException("expected 3 fields (name,email,department).");
                    }
                    addParticipant(f[0], f[1], f[2]);
                    summary.added++;
                } catch (InvalidInputException ex) {
                    summary.skipped++;
                    summary.errors.add("Line " + lineNo + ": " + ex.getMessage());
                }
            }
        }
        return summary;
    }

    // ---------------------------------------------------------- generation
    public File generateOne(Participant p, CertificateRenderer renderer, File outDir)
            throws InvalidInputException, IOException {
        requireEvent();
        File file = renderer.render(p, event, outDir);
        p.markGenerated();
        return file;
    }

    /**
     * Generates certificates for ALL participants using every given renderer and
     * writes a summary report. Returns the number of certificate files created.
     */
    public int generateAll(List<CertificateRenderer> renderers, File outDir)
            throws InvalidInputException, IOException {
        requireEvent();
        if (participants.isEmpty()) {
            throw new InvalidInputException("No participants registered.");
        }
        if (!outDir.exists() && !outDir.mkdirs()) {
            throw new IOException("Cannot create output folder: " + outDir);
        }
        int created = 0;
        StringBuilder report = new StringBuilder();
        report.append("CERTIFICATE GENERATION REPORT\n");
        report.append("Event      : ").append(event.getTitle()).append('\n');
        report.append("Event date : ").append(event.getFormattedDate()).append('\n');
        report.append("Generated  : ").append(LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))).append("\n\n");
        report.append(String.format("%-11s %-26s %-30s %s%n", "CERT ID", "NAME", "EMAIL", "STATUS"));

        for (Participant p : participants) {
            StringBuilder status = new StringBuilder();
            for (CertificateRenderer r : renderers) {
                try {
                    File f = r.render(p, event, outDir);
                    created++;
                    status.append("OK(").append(f.getName()).append(") ");
                } catch (IOException ex) {
                    status.append("FAILED(").append(r.getFormatName()).append(") ");
                }
            }
            p.markGenerated();
            report.append(String.format("%-11s %-26.26s %-30.30s %s%n",
                    p.getCertificateId(), p.getName(), p.getEmail(), status.toString().trim()));
        }
        report.append("\nTotal certificate files created: ").append(created).append('\n');
        Files.write(new File(outDir, REPORT_NAME).toPath(),
                report.toString().getBytes(StandardCharsets.UTF_8));
        return created;
    }

    private void requireEvent() throws InvalidInputException {
        if (event == null) {
            throw new InvalidInputException("Event details are not set. Use option 1 first.");
        }
    }
}
